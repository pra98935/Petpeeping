<?php
// Added some extra helpfull shortcodes to the membership system
?>